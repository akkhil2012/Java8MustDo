package org.example;


    class Asset{

        private  String name;

        private int score;

        public String getName() {
            return name;
        }

        public int getScore() {
            return score;
        }

        public Asset(String name, int score) {
            this.name = name;
            this.score = score;
        }
    }

