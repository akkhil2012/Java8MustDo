package biFunctionMap;

import java.sql.Connection;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class AbstractParamertrizedRetreiver<T> {


    private final String sqlQueryTemplate;

    public AbstractParamertrizedRetreiver(String sqlQueryTemplate, ResultSetMapper<T> mapper) {
        this.sqlQueryTemplate = sqlQueryTemplate;
        this.mapper = mapper;
    }

    private final ResultSetMapper<T> mapper;

    public <R> R retrieve(Connection connection, Collection<String> assetIds, Function<Stream<T>,R> igcAssetTransformFunction){
        PageIterator<String> assetRidsIterator = new PageIterator<>(assetIds);
        return igcAssetTransformFunction.apply(
                StreamSupport.stream(Spliterators.spliteratorUnknownSize(assetRidsIterator,Spliterator.ORDERED),false)
                        .flatMap(ids -> streamResultsForIds(connection, ids)));
    }


    private Stream<T> streamResultsForIds(Connection connection, List<String> ids) {
        String completedQuery = String.format(sqlQueryTemplate, String.join(",", Collections.nCopies(ids.size(), "?")));
        return SqlStreamingExecutor.stream(connection, completedQuery, mapper, ids).filter(Objects::nonNull);
    }


}
