package biFunctionMap;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class PageIterator<T> implements Iterator<List<T>> {


    public static final int MAX_NUMBER_OF_QUESTION_MARKS = 1000;
    private final Iterator<T> raw;
    private final int pageSize;

    public PageIterator(Collection<T> data) {
        this(data,MAX_NUMBER_OF_QUESTION_MARKS);
    }

    public PageIterator(Collection<T> data, int pageSize) {
        if (pageSize < 1 || pageSize > MAX_NUMBER_OF_QUESTION_MARKS) {
            throw new IllegalArgumentException("pageSize: " + pageSize);
        }
        this.raw = data.iterator();
        this.pageSize = pageSize;
    }

    @Override
    public boolean hasNext() {
        return raw.hasNext();
    }

    @Override
    public List<T> next() {
        List<T> page = new ArrayList<>();
        while (page.size() < pageSize && raw.hasNext()) {
            page.add(raw.next());
        }
        return page;
    }
}
