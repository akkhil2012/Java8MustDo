package biFunctionMap;

import org.example.AssetBatch;

import java.sql.Connection;
import java.util.Map;
import java.util.function.BiFunction;

import static java.util.Map.entry;

public class BiFunctionMapperExample {


    EdsChildrenRetriever edsChildRetriever;
    public static void main(String args[]){


        processAdditionalRelationship/// Start from here again

    }


    public void parseAdditionalFeatures(){
        Map<String, BiFunction<Connection, AssetBatch,Integer>>
                relsProcessorsMap = Map.ofEntries(entry("children",this::processChildren));
    }


    private Integer processChildren(Connection connection,AssetBatch assetBatch){
        return edsChildRetriever.retrieve(connection,assetBatch.getIds(),entryStream ->
                entryStream.map(e -> createChildRelationship(assetBatch,e))
                        .reduce(0,Integer::sum));
    }


}



